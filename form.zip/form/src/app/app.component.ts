import { Component } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { PasswordValidator } from './shared/password.validator';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private fb: FormBuilder) { }
  registrationForm = this.fb.group({
    userName: ['', [Validators.required, Validators.minLength(3)]],
    password: [''],
    confirmPassword: [''],
    phone : ['', [Validators.required,  Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
    email: ['' ,[Validators.required , Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
    
    address: this.fb.group({
      city: ['' ],
      state: [''],
      postalCode: ['']
    }),
}, { validator: PasswordValidator });


get userName() {
  return this.registrationForm.get('userName');
}
get email() {
  return this.registrationForm.get('email');
}
get phone() {
  return this.registrationForm.get('phone');
}

onSubmit() {
  console.log(this.registrationForm.value);

}


}
